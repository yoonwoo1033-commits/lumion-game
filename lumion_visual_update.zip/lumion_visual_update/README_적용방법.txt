LUMION 이미지 적용 패키지 (2026-11-08)

이 패키지에는 app.py 대체 파일과 assets/ 폴더가 있습니다.
기존 lumion-game 저장소의 engine.py, storage.py, requirements.txt는 그대로 유지하세요.

GitHub에서 lumion_standalone/ 폴더 안에 다음 구조가 되도록 올립니다.
  lumion_standalone/app.py             <- 이 패키지의 app.py로 교체
  lumion_standalone/engine.py          <- 기존 파일 유지
  lumion_standalone/storage.py         <- 기존 파일 유지
  lumion_standalone/requirements.txt   <- 기존 파일 유지
  lumion_standalone/assets/creatures/  <- 새 이미지 20개
  lumion_standalone/assets/scenes/     <- 새 배경 5개
  lumion_standalone/assets/items/      <- 새 아이템 8개

GitHub 웹에서는 app.py 파일의 연필(Edit) 버튼으로 내용을 바꿔 저장할 수 있습니다.
이미지는 GitHub Add file > Upload files에서 assets 폴더를 드래그해 업로드하거나
Cursor에서 폴더 전체를 프로젝트에 복사한 후 GitHub로 커밋/푸시하세요.
Streamlit main file path는 lumion_standalone/app.py 입니다.

주의:
- 이번 패키지는 생성된 한 장의 콘셉트 아트에서 잘라낸 이미지 20종, 아이템 8종, 배경 5종을 실제 UI에 연결합니다.
- 100종 개별 고해상도 원본, 오로라 100종, 24프레임 개별 애니메이션은 포함하지 않습니다.
- 그림 안에 원래 콘셉트 시트의 글자/테두리가 일부 남아 있을 수 있습니다.
- 기존 저장 방식은 테스트용 SQLite + URL player 식별 방식입니다. 공개 서비스에 쓰기 전 인증과 서버 저장을 바꿔야 합니다.
- 이미지의 이름 매칭은 시안입니다. 일부는 루미온 기존 도감과 정확히 일치하지 않습니다.
